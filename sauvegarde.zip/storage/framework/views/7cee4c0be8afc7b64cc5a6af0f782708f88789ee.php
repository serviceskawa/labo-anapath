<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right mr-3">
                    <a type="btn" href="<?php echo e(route('user.create')); ?> " class="btn btn-primary">Ajouter un nouveau
                        utilisateur</a>
                </div>
                <h4 class="page-title">Utilisateurs</h4>
            </div>

        </div>
    </div>
    <div class="">

        <?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card mb-md-0 mb-3">
            <div class="card-body">
                <div class="card-widgets">
                    <a href="javascript:;" data-bs-toggle="reload"><i class="mdi mdi-refresh"></i></a>
                    <a data-bs-toggle="collapse" href="#cardCollpase1" role="button" aria-expanded="false"
                        aria-controls="cardCollpase1"><i class="mdi mdi-minus"></i></a>
                    <a href="#" data-bs-toggle="remove"><i class="mdi mdi-close"></i></a>
                </div>
                <h5 class="card-title mb-0">Liste des Utilisateurs</h5>

                <div id="cardCollpase1" class="collapse pt-3 show">

                    <?php if(auth()->check()): ?>
                    <?php endif; ?>
                    <table id="datatable1" class="table table-striped dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>Nom</th>
                                <th>Email</th>
                                <th>Roles</th>
                                <th>Actions</th>
                            </tr>
                        </thead>


                        <tbody>

                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->firstname); ?> <?php echo e($item->lastname); ?></td>
                                    <td><?php echo e($item->email); ?> </td>
                                    <td>
                                        <?php $__empty_1 = true; $__currentLoopData = $item->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <span class="badge bg-primary"><?php echo e($role->name); ?> </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            Aucun
                                        <?php endif; ?>

                                    </td>

                                    <td> <a type="button" href="<?php echo e(route('user.edit', $item->id)); ?> "
                                            class="btn btn-primary"><i class="mdi mdi-eye"></i> </a>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('extra-js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kawa/gestion.caap.bj/resources/views/users/index.blade.php ENDPATH**/ ?>