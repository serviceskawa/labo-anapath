<?php
setlocale(LC_TIME, 'fr_FR');
date_default_timezone_set('Europe/Paris');

?>

<style>
    .border_b {
        border-bottom: 2px solid rgb(0, 0, 0, 0);
        border-radius: 5px;
    }

    .border_t {
        border-top: 2px solid rgb(0, 0, 0, 0);
        border-radius: 5px;
    }
</style>
<page backbottom="10mm">

    <div style="display:inline-block; ">
        <span style="display: inline-block;padding-top: 5px; font-size:25px; margin-top:-50px "><img
                src="<?php echo e(public_path('adminassets/images/Logo_long_CAAP@4x.png')); ?>" width="200px;" alt=""></span>
        <div
            style="display: inline-block; padding: 5px; position: absolute; top:20px; right: 0px; padding: 10px; text-align:right;">
            <b><span style="font-size:17px; text-align:right;"> CENTRE ADECHINA ANATOMIE PATHOLOGIQUE</span></b>
            <br><span style="font-size:10px; text-align:right;">Laboratoire d’Anatomie Pathologique</span>
        </div>
    </div>
    <div style="display: inline-block; position: absolute; right: 0px;width: 200px;padding: 10px;  margin-top:-20px">
        <p>
            <b>N° ANAPTH :</b> <?php echo e($code); ?>

            <br>
            <b>Date :</b> <?php echo e($current_date); ?>

        </p>
    </div>
    <div
        style="margin-top:20px; background-color:#0070C1; width:100%; height:50px;color:rgb(255,255,255); text-align: center; padding-top:19px;font-size:25px;">
        <b>COMPTE RENDU HISTOPATHOLOGIQUE</b>
    </div>
    <br><br>
    <div>
        <h3 style="padding-left: 5px; padding-right: 5px; border:none; background-color:rgb(255,255,255); text-transform: uppercase; color:#0070C1; ">
            <b>Informations prélèvement</b>
        </h3>

            <p style="margin-left:10px; margin-right:10px; display:block; width: 100%;">

            <table style="max-width: 100%;width: 500px ">
                <tbody>
                    <tr>
                        <th width="25%;">Nom :</th>
                        <td width="25%;"><?php echo e($patient_firstname); ?> </td>
                        <th width="40%;">Date prélèvement : </th>
                        <td width="20%;"><?php echo e($prelevement_date); ?> </td>
                    </tr>
                    <tr>
                        <th>Prénoms :</th>
                        <td><?php echo e($patient_lastname); ?> </td>
                        <th>Date d’arrivée labo : </th>
                        <td> <?php echo e($created_at); ?> </td>
                    </tr>
                    <tr>
                        <th>Age :</th>
                        <td><?php echo e($patient_age); ?> </td>
                        <th>Service demandeur :</th>
                        <td><?php echo e($hospital_name); ?> </td>
                    </tr>
                    <tr>
                        <th>Sexe :</th>
                        <td><?php echo e($patient_genre); ?> </td>
                        <th>Médecin prescripteur : </th>
                        <td> <?php echo e($doctor_name); ?> </td>
                    </tr>
                </tbody>
            </table>
            </p>
            <br>
    </div>

    <h3 style="padding-left: 5px; padding-right: 5px; border:none; background-color:rgb(255,255,255); text-transform: uppercase; color:#0070C1; ">
        <b>Récapitulatifs</b>
    </h3>
    
    
        <?php echo $content; ?>

    
    

    

    <div style="">
        <table style="width: 100%;">
            <tr>
                <!-- <td style="text-align: left;    width: 10%"></td> -->

                <td style="text-align: center;    width: 33%">
                    <?php if($signatory1 != null): ?>
                        <img width="100" src="<?php echo e(storage_path('app/public/' . $signature1)); ?>"
                            alt=""><br><br><?php echo e($signatory1); ?>

                    <?php endif; ?>
                </td>
                <td style="text-align: center;    width: 33%">
                    <?php if($signatory2 != null): ?>
                        <img width="200" src="<?php echo e(storage_path('app/public/' . $signature2)); ?>"
                            alt=""><br><br><?php echo e($signatory2); ?>

                    <?php endif; ?>

                </td>
                <td style="text-align: center;    width: 33%">
                    <?php if($signatory3 != null): ?>
                        <img width="85" src="<?php echo e(storage_path('app/public/' . $signature3)); ?>"
                            alt=""><br><br><?php echo e($signatory3); ?>

                    <?php endif; ?>
                </td>
            </tr>
        </table>

    </div>
    <br><br>
    <page_footer>
        <table style="width: 100%; margin-top:1em !important">
            <tr>
                <td style="text-align: left; width: 100%; font-size:12px;"> Centre ADECHINA Anatomie Pathologique • <br>
                    Adresse : Carre 1915 "G" Fifadji, 072 BP 059 Cotonou, Benin • Téléphone : (+229)96110311 • RCCM
                    RB/COT/18 B22364<br>
                    Contact@caap.bj • Ouvert du Lundi au Vendredi de 08:00 - 17:00 • www.caap.bj
                </td>
            </tr>
        </table>
    </page_footer>
</page>
<?php /**PATH /home/kawa/gestion.caap.bj/resources/views/pdf/canva.blade.php ENDPATH**/ ?>