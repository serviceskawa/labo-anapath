<?php $__env->startSection('title', 'Paramètres système'); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('/adminassets/css/vendor/quill.core.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/adminassets/css/vendor/quill.snow.css')); ?>" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.css"
    integrity="sha512-In/+MILhf6UMDJU4ZhDL0R0fEpsp4D3Le23m6+ujDWXwl3whwpucJG1PEmI3B07nyJx+875ccs+yX2CqQJUxUw=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />

<style>
    .ck-editor__editable[role="textbox"] {
        /* editing area */
        min-height: 200px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right mr-3 mb-1">
                <a href="<?php echo e(route('home')); ?>" type="button" class="btn btn-primary">Acceuil</a>
            </div>
            <h4 class="page-title"></h4>
        </div>


    </div>
</div>


<div class="">


    <?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="header-title">Paramètres du Systeme</h4>
                <p class="text-muted font-14">

                </p>

                <ul class="nav nav-tabs nav-bordered mb-3">
                    <li class="nav-item">
                        <a href="#input-types-preview" data-bs-toggle="tab" aria-expanded="false"
                            class="nav-link active">
                            Informations
                        </a>
                    </li>
                    
                </ul> <!-- end nav-->

                <div class="tab-content">
                    <div class="tab-pane show active" id="input-types-preview">
                        <form action="<?php echo e(route('settings.app-store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row mb-3">
                                <label for="" class="form-label">Nom du site</label>
                                <div class="col-lg-12">
                                    <input type="text" name="titre" id="" class="form-control"
                                        value="<?php echo e($setting ? $setting->titre : ''); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">


                                <div class="col-lg-4">

                                    <div class="mb-3">
                                        <label for="example-fileinput" class="form-label">Logo</label>
                                        <input type="file" class="dropify" name="logo"
                                            data-default-file="<?php echo e($setting ? Storage::url($setting->logo) : ''); ?>"
                                            data-max-file-size="3M" />
                                    </div>


                                </div> <!-- end col -->

                                <div class="col-lg-4">

                                    <div class="mb-3">
                                        <label for="example-fileinput" class="form-label">Favicon</label>
                                        <input type="file" class="dropify" name="favicon"
                                            data-default-file="<?php echo e($setting ? Storage::url($setting->favicon) : ''); ?>"
                                            data-max-file-size="3M" />
                                    </div>


                                </div> <!-- end col -->

                                <div class="col-lg-4">

                                    <div class="mb-3">
                                        <label for="example-fileinput" class="form-label">Logo Blanc</label>
                                        <input type="file" class="dropify" name="img3"
                                            data-default-file="<?php echo e($setting ? Storage::url($setting->logo_blanc) : ''); ?>"
                                            data-max-file-size="3M" />
                                    </div>


                                </div> <!-- end col -->
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-6">
                                    <label for="" class="form-label">Server SMS</label>

                                    <input type="text" name="server_sms" id="" class="form-control"
                                        value="<?php echo e($setting ? $setting->server_sms : ''); ?>">
                                </div>
                                <div class="col-lg-6">
                                    <label for="" class="form-label">Api Key SMS</label>

                                    <input type="text" name="api_key_sms" id="" class="form-control"
                                        value="<?php echo e($setting ? $setting->api_key_sms : ''); ?>">
                                </div>
                            </div>
                            <div class="card-footer">
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-xs btn-success">Update</button>
                                </div>
                            </div> <!-- end card-body -->
                        </form>
                        <!-- end row-->
                    </div> <!-- end preview-->
                    <div class="tab-pane" id="input-types-code">
                        <pre class="mb-0">
                                <span class="html escape">

                                </span>
                            </pre> <!-- end highlight-->
                    </div>
                </div> <!-- end tab-content-->
            </div>

        </div> <!-- end card -->
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('extra-js'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/35.1.0/classic/ckeditor.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.min.js"
    integrity="sha512-8QFTrG0oeOiyWo/VM9Y8kgxdlCryqhIxVeRpWSezdRRAvarxVtwLnGroJgnVW9/XBRduxO/z1GblzPrMQoeuew=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    $('.dropify').dropify();
</script>
<script>
    ClassicEditor
            .create(document.querySelector('#editor'))
            .catch(error => {
                console.error(error);
            });
</script>
<script>
    ClassicEditor
            .create(document.querySelector('#editor2'))
            .catch(error => {
                console.error(error);
            });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kawa/gestion.caap.bj/resources/views/settings/app/index.blade.php ENDPATH**/ ?>