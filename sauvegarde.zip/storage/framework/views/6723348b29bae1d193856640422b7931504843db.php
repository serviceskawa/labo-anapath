<?php $__env->startSection('title', 'Details examen'); ?>
<?php $__env->startSection('content'); ?>
<div class="">

    <?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    

    <div class="card my-3">
        <?php if($test_order->status == 1): ?>
        <a href="<?php echo e(route('report.show', empty($test_order->report->id) ? '' : $test_order->report->id)); ?>"
            class="btn btn-success w-full">CONSULTEZ LE
            COMPTE RENDU</a>
        <?php endif; ?>

        <div class="card-header">
            Demande d'examen : <strong><?php echo e($test_order->code); ?></strong>
        </div>
        <div class="card-body">


            <div class="row">
                <div class="mb-3 col-md-6">
                    <label for="simpleinput" class="form-label">Patient</label>
                    <input type="text" name="name"
                        value="<?php echo e($test_order->getPatient()->lastname); ?> <?php echo e($test_order->getPatient()->firstname); ?> - <?php echo e($test_order->getPatient()->code); ?>"
                        class="form-control" readonly>
                </div>

                <div class="mb-3 col-md-6">
                    <label for="simpleinput" class="form-label">Médecin traitant</label>
                    <input type="text" name="name" value="<?php echo e($test_order->getDoctor()->name); ?>" class="form-control"
                        readonly>
                </div>

                <input id="contrat_id" type="hidden" value="<?php echo e($test_order->getContrat()->id); ?>">
            </div>


            <div class="row">
                <div class="mb-3 col-md-6">
                    <label for="exampleFormControlInput1" class="form-label">Référence hôpital</label>
                    <input class="form-control" name="reference_hopital" value="<?php echo e($test_order->reference_hopital); ?>"
                        readonly>
                </div>

                <div class="mb-3 col-md-6">
                    <label for="simpleinput" class="form-label">Hôpital de provenance</label>
                    <input type="text" name="name" value="<?php echo e($test_order->getHospital()->name); ?>" class="form-control"
                        readonly>
                </div>
            </div>

            <div class="col-mb-12">
                <label class="form-label">Date prélèvement</label>
                <input type="text" class="form-control date" name="prelevement_date" id="prelevement_date"
                    value="<?php echo e($test_order->prelevement_date); ?>" readonly>
            </div>

            <div class="mb-3">
                <div class="form-group">
                    <label for="simpleinput" class="form-label">Contrat</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($test_order->getContrat()->name); ?>"
                        readonly>
                </div>
            </div>
        </div>
    </div>

    <div class="card mb-md-0 mb-3">
        <div class="card-header">
            Liste des examens demandés
        </div>
        <h5 class="card-title mb-0"></h5>

        <div class="card-body">

            <!-- Ajouter un examen | si le statut de la demande est 1 alors on peut plus ajouter de nouveau examen dans la demande-->
            <?php if($test_order->status != 1): ?>
            <form method="POST" id="addDetailForm" autocomplete="off">
                <?php echo csrf_field(); ?>
                <div class="row d-flex align-items-end">
                    <div class="col-md-4 col-12">
                        <input type="hidden" name="test_order_id" id="test_order_id" value="<?php echo e($test_order->id); ?>"
                            class="form-control">

                        <div class="mb-3">
                            <label for="example-select" class="form-label">Examen</label>
                            <select class="form-select select2" data-toggle="select2" id="test_id" name="test_id"
                                required onchange="getTest()">
                                <option>Sélectionner l'examen</option>
                                <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option data-category_test_id="<?php echo e($test->category_test_id); ?>" value="<?php echo e($test->id); ?>"><?php echo e($test->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </select>
                        </div>
                    </div>
                    <div class="col-md-2 col-12">

                        <div class="mb-3">
                            <label for="simpleinput" class="form-label">Prix</label>
                            <input type="text" name="price" id="price" class="form-control" required readonly>
                        </div>
                    </div>
                    <div class="col-md-2 col-12">
                        <div class="mb-3">
                            <label for="simpleinput" class="form-label">Remise</label>
                            <input type="text" name="remise" id="remise" class="form-control" required readonly>
                        </div>
                    </div>
                    <div class="col-md-2 col-12">
                        <div class="mb-3">
                            <label for="example-select" class="form-label">Total</label>

                            <input type="text" name="total" id="total" class="form-control" required readonly>
                        </div>
                    </div>

                    <div class="col-md-2 col-12">
                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary" id="add_detail">Ajouter</button>

                        </div>
                    </div>
                </div>

            </form>
            <?php endif; ?>

            <div id="cardCollpase1" class="collapse pt-3 show">


                <table id="datatable1" class="table detail-list-table table-striped dt-responsive nowrap w-100">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Examen</th>
                            <th>Prix</th>
                            <th>Remise</th>
                            <th>Montant</th>
                            <th>Actions</th>

                        </tr>
                    </thead>


                    <tfoot>
                        <tr>
                            <td colspan="1" class="text-right">
                                <strong>Total:</strong>
                            </td>
                            <td></td>
                            <td></td>
                            <td></td>

                            <td id="val">
                                <input type="number" id="estimated_ammount" class="estimated_ammount" value="0"
                                    readonly>
                            </td>
                            <td></td>

                        </tr>
                    </tfoot>
                </table>

                <div class="row mt-2 mx-3">
                    <?php if($test_order->status != 1): ?>
                    <a type="submit" href="<?php echo e(route('test_order.updatestatus', $test_order->id)); ?>" id="finalisationBtn"
                        class="btn btn-info w-full disabled">ENREGISTRER</a>
                    <?php endif; ?>
                    <?php if($test_order->status == 1): ?>
                    <a href="<?php echo e(route('report.show', empty($test_order->report->id) ? '' : $test_order->report->id)); ?>"
                        class="btn btn-success w-full">CONSULTEZ LE
                        COMPTE RENDU</a>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div> <!-- end card-->

</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('extra-js'); ?>
<script></script>
<script type="text/javascript">
    $(document).ready(function() {
            var test_order = <?php echo json_encode($test_order); ?>

            // console.log(test_order)

            var dtDetailTable = $('.detail-list-table')

            var dt_basic = $('#datatable1').DataTable({
                ajax: {
                    url: '/test_order/detailstest/' + test_order.id,
                    dataSrc: ''
                },
                // deferRender: true,
                columns: [
                    // columns according to JSON
                    {
                        data: 'id'
                    },
                    {
                        data: 'test_name'
                    },
                    {
                        data: 'price'
                    },
                    {
                        data: 'discount'
                    },
                    {
                        data: 'total'
                    },
                    {
                        data: null
                    }
                ],
                columnDefs: [{
                    "targets": -1,
                    "render": function(data, type, row) {
                        if (row["status"] != 1) {
                            return (
                                '<button type="button" id="deleteBtn" class="btn btn-danger"><i class="mdi mdi-trash-can-outline"></i> </button>'
                            );
                        }
                        return "";
                    }

                }],

                footerCallback: function(row, data, start, end, display) {
                    var api = this.api();

                    // Remove the formatting to get integer data for summation
                    var intVal = function(i) {
                        return typeof i === 'string' ? i.replace(/[\$,]/g, '') * 1 : typeof i ===
                            'number' ? i : 0;
                    };

                    // Total over all pages
                    total = api
                        .column(4)
                        .data()
                        .reduce(function(a, b) {
                            return intVal(a) + intVal(b);
                        }, 0);
                    // 
                    discount = api
                        .column(3)
                        .data()
                        .reduce(function(a, b) {
                            return intVal(a) + intVal(b);
                        }, 0);

                    subTotal = api
                        .column(2)
                        .data()
                        .reduce(function(a, b) {
                            return intVal(a) + intVal(b);
                        }, 0);

                    // Update footer
                    $(api.column(4).footer()).html(total);
                    $(api.column(3).footer()).html(discount);
                    $(api.column(2).footer()).html(subTotal);

                    sendTotal(test_order.id, total, discount, subTotal);

                    // if ($(api.column(4).footer()).html(total)) {
                    //     // console.log('footer');
                    // }

                    var numRows = api.rows().count();
                    if (numRows > 0) {
                        var element = document.getElementById('finalisationBtn');

                        element.classList.remove("disabled");
                    }
                },

            });

            // setInterval(function() {
            //     dt_basic.ajax.reload();
            // }, 3000);

            // 
            $('.detail-list-table tbody').on('click', '#deleteBtn', function() {
                var data = dt_basic.row($(this).parents('tr')).data();
                var id = $(this).data('id');
                console.log(data)
                Swal.fire({
                    title: "Voulez-vous supprimer l'élément ?",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonText: "Oui ",
                    cancelButtonText: "Non !",
                }).then(function(result) {
                    if (result.value) {
                        // window.location.href = "<?php echo e(url('contrats_details/delete')); ?>" + "/" + id;
                        $.ajax({
                            url: "/test_order/detailsdelete",
                            type: "post",
                            data: {
                                "_token": "<?php echo e(csrf_token()); ?>",
                                id: data.id,
                            },
                            success: function(response) {

                                console.log(response);
                                Swal.fire(
                                    "Suppression !",
                                    "En cours de traitement ...",
                                    "success"
                                )
                                dt_basic.ajax.reload()
                                // window.location.reload();
                            },
                            error: function(response) {
                                console.log(response);
                                dt_basic.ajax.reload()

                                // Command: toastr["error"]("Error")
                            },
                        });

                    }
                });
            });

            function sendTotal(test_order_id, total, discount, subTotal) {
                console.log(test_order_id, total, discount, subTotal);

                $.ajax({
                    url: "<?php echo e(route('test_order.updateorder')); ?>",
                    type: "POST",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        test_order_id: test_order_id,
                        discount: discount,
                        subTotal: subTotal,
                        total: total

                    },
                    success: function(response) {
                        console.log(response)

                    },
                    error: function(response) {
                        console.log(response)
                    },
                });
            };

        });

        $('#addDetailForm').on('submit', function(e) {
            e.preventDefault();
            let test_order_id = $('#test_order_id').val();
            let test_id = $('#test_id').val();
            let price = $('#price').val();
            let remise = $('#remise').val();
            let total = $('#total').val();

            $.ajax({
                url: "<?php echo e(route('details_test_order.store')); ?>",
                type: "POST",
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    test_order_id: test_order_id,
                    test_id: test_id,
                    price: price,
                    discount: remise,
                    total: total

                },
                success: function(response) {
                    $('#addDetailForm').trigger("reset")

                    if (response) {
                        toastr.success("Donnée ajoutée avec succès", 'Ajout réussi');
                    }
                    $('#datatable1').DataTable().ajax.reload();
                    // $('#addDetailForm').trigger("reset")
                    // updateSubTotal();
                },
                error: function(response) {
                    console.log(response)
                },
            });

        });

        function getTest() {
            var test_id = $('#test_id').val();

            // Importation des paramètres de getRemise
            var contrat_id = $('#contrat_id').val();
            let element = document.getElementById("test_id");
            let category_test_id = element.options[element.selectedIndex].getAttribute("data-category_test_id");

            $.ajax({
                type: "POST",
                url: "<?php echo e(route('examens.getTestAndRemise')); ?>",
                data:{
                    "_token": "<?php echo e(csrf_token()); ?>",
                    testId:test_id, 
                    contratId:contrat_id, 
                    categoryTestId:category_test_id
                },
                success: function(data) {

                    $('#price').val(data.data.price);

                    var discount = $('#price').val() * data.detail / 100;
                    $('#remise').val(discount);

                    var total = $('#price').val() - discount;
                    $('#total').val(total);

                },
                error: function(data) {
                    console.log('Error:', data);
                }
            });

        }

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kawa/gestion.caap.bj/resources/views/examens/details/index.blade.php ENDPATH**/ ?>