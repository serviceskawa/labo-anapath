

<?php $__env->startSection('title', 'Details'); ?>

<?php $__env->startSection('css'); ?>

    <style>
        .ck-editor__editable[role="textbox"] {
            /* editing area */
            min-height: 200px;
        }
    </style>

    <!-- Quill css -->
    <link href="<?php echo e(asset('adminassets/css/vendor/quill.core.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('adminassets/css/vendor/quill.snow.css')); ?>" rel="stylesheet" type="text/css" />
    <script src="https://cdn.ckeditor.com/ckeditor5/36.0.0/super-build/ckeditor.js"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right mr-3 mb-1">
                    <a href="<?php echo e(route('report.index')); ?>" type="button" class="btn btn-primary">Retour à la liste des
                        comptes rendus</a>
                </div>
                <h4 class="page-title">Compte rendu</h4>
            </div>
        </div>
    </div>

    <div class="">

        <?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row">
            <!-- Contenu du compte rendu -->
            <div class="col-9">
                <div class="card mb-md-0 mb-3">
                    <!-- <h5 class="card-header">Contenu du compte rendu</h5> -->

                    <div class="card-body">
                        <div id="cardCollpase1" class="show collapse pt-3">
                            <div style="text-align:right;"><span style="color:red;">*</span>champs obligatoires</div>

                            <form action="<?php echo e(route('report.store')); ?>" id="reportForm" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Template</label>
                                        <select class="form-select" id="template" name="">
                                            <option value="">Sélectionner un template</option>
                                            <?php $__empty_1 = true; $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($template->id); ?>"><?php echo e($template->title); ?> </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>

                                <input type="hidden" name="report_id" value="<?php echo e($report->id); ?>">

                                <div class="row">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Récapitulatifs<span
                                                style="color:red;">*</span></label>
                                        <textarea name="content" id="editor" class="form-control mb-3" cols="30" rows="50" style="height: 500px;"><?php echo e($report->description); ?></textarea>
                                        
                                    </div>
                                </div>

                                <div class="row my-3">
                                    <label for="simpleinput" class="form-label">Cocher les signataires du compte rendu<span
                                            style="color:red;">*</span></label>
                                    <div class="">

                                        <div class="form-check form-check-inline">
                                            <input type="checkbox" class="form-check-input"
                                                <?php echo e($report->signatory1 == '1' ? 'checked' : ''); ?> name="signatory1"
                                                id="customCheck3">
                                            <label class="form-check-label"
                                                for="customCheck3"><?php echo e($setting->signatory1); ?></label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input type="checkbox" class="form-check-input"
                                                <?php echo e($report->signatory2 == '1' ? 'checked' : ''); ?> name="signatory2"
                                                id="customCheck3">
                                            <label class="form-check-label"
                                                for="customCheck3"><?php echo e($setting->signatory2); ?></label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input type="checkbox" class="form-check-input"
                                                <?php echo e($report->signatory3 == '1' ? 'checked' : ''); ?> name="signatory3"
                                                id="customCheck3">
                                            <label class="form-check-label"
                                                for="customCheck3"><?php echo e($setting->signatory3); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label mb-3">Etat du compte rendu<span
                                                style="color:red;">*</span></label>
                                        <select class="form-select" name="status">
                                            <option value="0" <?php echo e($report->status == 0 ? 'selected' : ''); ?>>En attente
                                                de
                                                relecture</option>
                                            <option value="1" <?php echo e($report->status == 1 ? 'selected' : ''); ?>>Terminé
                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-warning w-100 mt-3">Mettre à jour</button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>

            <!-- Colonne laterale -->
            <div class="col-3">

                <!-- Etat du compte rendu -->
                <div class="card mb-md-0 mb-3">
                    <h5 class="card-header">État du compte rendu</h5>
                    <div class="card-body">
                        <p><b>État</b> : <?php echo e($report->status == 0 ? 'En attente de relecture' : 'Terminé'); ?></p>
                        <p><b>Créé le</b> : <?php echo e(date_format($report->created_at, 'd/m/Y')); ?></p>
                        <p><b>Dernière mise à jour</b> : <?php echo e(date_format($report->updated_at, 'd/m/Y')); ?></p>
                    </div>
                </div>

                <!-- Info patient -->
                <div class="card mb-md-0 mb-3 mt-3">
                    <h5 class="card-header">Informations patient</h5>

                    <div class="card-body">
                        <p><b>Nom</b> : <?php echo e($report->patient->lastname); ?> <?php echo e($report->patient->firstname); ?></p>
                        <p><b>Code patient</b> : <?php echo e($report->patient->code); ?></p>
                        <p><b>Téléphone</b> : <?php echo e($report->patient->telephone1); ?></p>
                    </div>
                </div>

                <div class="card mb-md-0 mb-3 mt-3">
                    <h5 class="card-header">Signataires</h5>

                    <div class="card-body">
                        <p><b>Signature 1</b> : <?php echo e($report->signatory1 == 0 ? 'Inactif' : getSignatory1(1)); ?></p>
                        <p><b>Signature 2</b> : <?php echo e($report->signatory2 == 0 ? 'Inactif' : getSignatory2(1)); ?></p>
                        <p><b>Signature 3</b> : <?php echo e($report->signatory3 == 0 ? 'Inactif' : getSignatory3(1)); ?></p>
                    </div>

                </div>

                <div class="mb-md-0 mb-3 mt-3">
                    <div class="page-title">
                        <a href="<?php echo e(route('report.pdf', $report->id)); ?>" target="_blank" rel="noopener noreferrer"
                            type="button" class="btn btn-secondary">
                            <i class="uil uil-print">Imprimer le compte rendu</i>
                        </a>
                    </div>
                </div>

            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('extra-js'); ?>
    
    
    

    <script>
        // This sample still does not showcase all CKEditor 5 features (!)
        // Visit https://ckeditor.com/docs/ckeditor5/latest/features/index.html to browse all the features.
        const ck_options = {
            // https://ckeditor.com/docs/ckeditor5/latest/features/toolbar/toolbar.html#extended-toolbar-configuration-format
            toolbar: {
                items: [

                    'findAndReplace', 'selectAll', '|',
                    'heading', '|',
                    'bold', 'italic', 'underline', 'code', 'removeFormat', '|',
                    'bulletedList', 'numberedList', 'todoList', '|',
                    'outdent', 'indent', '|',
                    'undo', 'redo', '-',
                    'fontSize', 'fontFamily', 'fontColor', 'fontBackgroundColor', 'highlight', '|',
                    'alignment', '|',
                    'link', 'blockQuote', '|',
                    'specialCharacters', 'horizontalLine', 'pageBreak', '|',
                    'sourceEditing'
                ],
                shouldNotGroupWhenFull: true
            },
            // Changing the language of the interface requires loading the language file using the <script> tag.
            // language: 'es',
            list: {
                properties: {
                    styles: true,
                    startIndex: true,
                    reversed: true
                }
            },
            // https://ckeditor.com/docs/ckeditor5/latest/features/headings.html#configuration
            heading: {
                options: [{
                        model: 'paragraph',
                        title: 'Paragraph',
                        class: 'ck-heading_paragraph'
                    },
                    {
                        model: 'heading1',
                        view: 'h1',
                        title: 'Heading 1',
                        class: 'ck-heading_heading1'
                    },
                    {
                        model: 'heading2',
                        view: 'h2',
                        title: 'Heading 2',
                        class: 'ck-heading_heading2'
                    },
                    {
                        model: 'heading3',
                        view: 'h3',
                        title: 'Heading 3',
                        class: 'ck-heading_heading3'
                    },
                    {
                        model: 'heading4',
                        view: 'h4',
                        title: 'Heading 4',
                        class: 'ck-heading_heading4'
                    },
                    {
                        model: 'heading5',
                        view: 'h5',
                        title: 'Heading 5',
                        class: 'ck-heading_heading5'
                    },
                    {
                        model: 'heading6',
                        view: 'h6',
                        title: 'Heading 6',
                        class: 'ck-heading_heading6'
                    }
                ]
            },
            // https://ckeditor.com/docs/ckeditor5/latest/features/font.html#configuring-the-font-family-feature
            fontFamily: {
                options: [
                    'default',
                    'Arial, Helvetica, sans-serif',
                    'Courier New, Courier, monospace',
                    'Georgia, serif',
                    'Lucida Sans Unicode, Lucida Grande, sans-serif',
                    'Tahoma, Geneva, sans-serif',
                    'Times New Roman, Times, serif',
                    'Trebuchet MS, Helvetica, sans-serif',
                    'Verdana, Geneva, sans-serif'
                ],
                supportAllValues: true
            },
            // https://ckeditor.com/docs/ckeditor5/latest/features/font.html#configuring-the-font-size-feature
            fontSize: {
                options: [10, 12, 14, 'default', 18, 20, 22],
                supportAllValues: true
            },
            // https://ckeditor.com/docs/ckeditor5/latest/features/link.html#custom-link-attributes-decorators
            link: {
                decorators: {
                    addTargetToExternalLinks: true,
                    defaultProtocol: 'https://',
                    toggleDownloadable: {
                        mode: 'manual',
                        label: 'Downloadable',
                        attributes: {
                            download: 'file'
                        }
                    }
                }
            },
            // https://ckeditor.com/docs/ckeditor5/latest/features/mentions.html#configuration
            mention: {
                feeds: [{
                    marker: '@',
                    feed: [
                        '@apple', '@bears', '@brownie', '@cake', '@cake', '@candy', '@canes',
                        '@chocolate', '@cookie', '@cotton', '@cream',
                        '@cupcake', '@danish', '@donut', '@dragée', '@fruitcake', '@gingerbread',
                        '@gummi', '@ice', '@jelly-o',
                        '@liquorice', '@macaroon', '@marzipan', '@oat', '@pie', '@plum', '@pudding',
                        '@sesame', '@snaps', '@soufflé',
                        '@sugar', '@sweet', '@topping', '@wafer'
                    ],
                    minimumCharacters: 1
                }]
            },
            // The "super-build" contains more premium features that require additional configuration, disable them below.
            // Do not turn them on unless you read the documentation and know how to configure them and setup the editor.
            removePlugins: [
                // These two are commercial, but you can try them out without registering to a trial.
                // 'ExportPdf',
                // 'ExportWord',
                'CKBox',
                'CKFinder',
                'EasyImage',
                // This sample uses the Base64UploadAdapter to handle image uploads as it requires no configuration.
                // https://ckeditor.com/docs/ckeditor5/latest/features/images/image-upload/base64-upload-adapter.html
                // Storing images as Base64 is usually a very bad idea.
                // Replace it on production website with other solutions:
                // https://ckeditor.com/docs/ckeditor5/latest/features/images/image-upload/image-upload.html
                // 'Base64UploadAdapter',
                'RealTimeCollaborativeComments',
                'RealTimeCollaborativeTrackChanges',
                'RealTimeCollaborativeRevisionHistory',
                'PresenceList',
                'Comments',
                'TrackChanges',
                'TrackChangesData',
                'RevisionHistory',
                'Pagination',
                'WProofreader',
                // Careful, with the Mathtype plugin CKEditor will not load when loading this sample
                // from a local file system (file://) - load this site via HTTP server if you enable MathType
                'MathType'
            ]
        };
        CKEDITOR.ClassicEditor.create(document.getElementById("editor"), ck_options);
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#template').on('change', function(e) {
                var template_id = $('#template').val();
                const report = <?php echo json_encode($report); ?>;

                $.ajax({
                    url: "<?php echo e(route('template.report-getTemplate')); ?>",
                    type: "POST",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        id: template_id,
                    },
                    success: function(data) {
                        console.log(data);
                        // $('#page_id').val()
                        if (data) {
                            $('#editor').val(data.content);

                            CKEDITOR.ClassicEditor
                                .create(document.querySelector('#editor'), ck_options)
                                .then(editor => {})
                                .catch(error => {
                                    console.error(error);
                                });

                            document.querySelector('.ck-editor__editable').ckeditorInstance
                                .destroy()

                        } else {
                            $('#editor').val("Texte");

                            ClassicEditor
                                .create(document.querySelector('#editor'))
                                .then(editor => {})
                                .catch(error => {
                                    console.error(error);
                                });

                            document.querySelector('.ck-editor__editable').ckeditorInstance
                                .destroy()

                        }

                    },
                    error: function(error) {
                        $('#editor').val(report.description);

                        ClassicEditor
                            .create(document.querySelector('#editor'))
                            .then(editor => {})
                            .catch(error => {
                                console.error(error);
                            });

                        document.querySelector('.ck-editor__editable').ckeditorInstance
                            .destroy()

                    }
                })
            });
        });
    </script>

    <!-- quill js -->
    <script src="<?php echo e(asset('adminassets/js/vendor/quill.min.js')); ?>"></script>
    <!-- quill Init js-->
    
    <script>
        var quill = new Quill("#snow-editor", {
                theme: "snow",
                modules: {
                    toolbar: [
                        [{
                            font: []
                        }, {
                            size: []
                        }],
                        ["bold", "italic", "underline", "strike"],
                        [{
                            color: []
                        }, {
                            background: []
                        }],
                        [{
                            script: "super"
                        }, {
                            script: "sub"
                        }],
                        [{
                            header: [!1, 1, 2, 3, 4, 5, 6]
                        }, "blockquote", "code-block"],
                        [{
                            list: "ordered"
                        }, {
                            list: "bullet"
                        }, {
                            indent: "-1"
                        }, {
                            indent: "+1"
                        }],
                        ["direction", {
                            align: []
                        }],
                        ["link", "image", "video"],
                        ["clean"]
                    ]
                }
            }),
            quill = new Quill("#bubble-editor", {
                theme: "bubble"
            });

        var form = document.querySelector("reportForm");
        var hiddenInput = document.querySelector('#snow-editor-hidden');

        form.onsubmit = function() {
            alert('a')
            // // Populate hidden form on submit
            // var comment = document.querySelector('input[name=comment]');

            // //comment.value = JSON.stringify(quill.getContents());
            // comment.value = quill.root.innerHTML;
            // console.log(comment.value)

            // // console.log("Submitted", $(form).serialize(), $(form).serializeArray());

            // // No back end to actually submit to!
            // // alert('Open the console to see the submit data!')
            // // return false;

        };
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kawa/gestion.caap.bj/resources/views/reports/show.blade.php ENDPATH**/ ?>