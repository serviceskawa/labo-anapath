<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success" role="alert">
        <i class="dripicons-checkmark me-2"></i><strong>Succès!!</strong><?php echo $message; ?>

    </div>
<?php endif; ?>

<?php if($message = Session::get('error')): ?>
    <div class="alert alert-danger" role="alert">
        <i class="dripicons-wrong me-2"></i><strong>Erreur!!</strong> <?php echo $message; ?>

    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger" role="alert">
        <i class="dripicons-wrong me-2"></i><strong>Erreur!!</strong>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    </div>
<?php endif; ?>

<div class="alert alert-success" role="alert" id="success" style="display:none">
    <i class="dripicons-checkmark me-2"></i><strong>Succès!!</strong>
</div>
<?php /**PATH /home/kawa/gestion.caap.bj/resources/views/layouts/alerts.blade.php ENDPATH**/ ?>