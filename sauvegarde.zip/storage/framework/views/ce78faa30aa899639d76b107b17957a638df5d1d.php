<?php $__env->startSection('content'); ?>
    <div class="">

        <?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card my-3">
            <div class="card-header">
                Creer une nouvel utilisateur
            </div>
            <div class="card-body">

                <form action="<?php echo e(route('user.store')); ?>" method="post" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="row mb-3">
                        <div class="col-md-12 mb-3">
                            <div class="form-group">
                                <label for="exampleFormControlInput1" class="form-label">Nom</label>
                                <input type="text" class="form-control" name="firstname" required>
                            </div>
                        </div>
                        <div class="col-md-12 mb-3">
                            <div class="form-group">
                                <label for="exampleFormControlInput1" class="form-label">Prenom</label>
                                <input type="text" class="form-control" name="lastname" required>
                            </div>
                        </div>
                        <div class="col-md-12 mb-3">
                            <div class="form-group">
                                <label for="exampleFormControlInput1" class="form-label">Email</label>
                                <input type="email" class="form-control" name="email" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="example-select" class="form-label">Roles<span style="color:red;">*</span></label>
                            <select class="form-select select2" data-toggle="select2" required name="roles[]" multiple>
                                <option>Sélectionner les roles</option>
                                <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    Ajouter un role
                                <?php endif; ?>
                            </select>
                        </div>

                    </div>

            </div>

            <div class="modal-footer">
                <button type="reset" class="btn btn-light" data-bs-dismiss="modal">Annuler</button>
                <button type="submit" class="btn btn-primary">Creer</button>
            </div>


            </form>
        </div>


    </div>

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('extra-js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kawa/gestion.caap.bj/resources/views/users/create.blade.php ENDPATH**/ ?>