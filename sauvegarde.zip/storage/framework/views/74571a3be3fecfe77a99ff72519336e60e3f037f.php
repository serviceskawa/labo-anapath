<?php $__env->startSection('title', 'Details contrat'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right mr-3 mb-1">
                    <a href="<?php echo e(route('contrats.index')); ?>" type="button" class="btn btn-primary">Retour à la liste des
                        contrats</a>
                </div>
                <h4 class="page-title"></h4>
            </div>

            <!----MODAL---->

            <?php echo $__env->make('contrats_details.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->make('contrats_details.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>


    <div class="">


        <?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card mt-3">
            <h5 class="card-header">Contrat : <?php echo e($contrat->name); ?></h5>

            <div class="card-body">
                <p><b>Type</b> : <?php echo e($contrat->type); ?></p>
                <p><b>Statut</b> : <?php echo e($contrat->status); ?></p>
                <p><b>Description</b> : <?php echo e($contrat->description); ?></p>
            </div>
        </div>

        <div class="card mb-md-0 mb-3">


            <div class="card-body">
                <div class="card-widgets">
                    <button type="button" class="btn btn-warning float-left" data-bs-toggle="modal"
                        data-bs-target="#modal2">Ajouter une nouvelle catégorie d'examen</button>
                </div>
                <h5 class="card-title mb-0">Catégories d'examen prises en compte</h5>


                <div id="cardCollpase1" class="collapse pt-3 show">


                    <table id="datatable1" class="table table-striped dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>Catégorie d'examen</th>
                                <th>Pourcentage</th>
                                <th>Actions</th>
                            </tr>
                        </thead>


                        <tbody>
                            <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->categorytest()->name); ?></td>
                                    <td><?php echo e($item->pourcentage . ' %'); ?></td>
                                    <td>
                                        <button type="button" onclick="edit(<?php echo e($item->id); ?>)"
                                            class="btn btn-primary"><i class="mdi mdi-lead-pencil"></i> </button>
                                        <button type="button" onclick="deleteModal(<?php echo e($item->id); ?>)"
                                            class="btn btn-danger"><i class="mdi mdi-trash-can-outline"></i> </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <span class="d-inline" data-bs-toggle="popover"
                        data-bs-content="Veuillez ajouter un detail avant de sauvegarder">

                        <a type="button" href="<?php echo e(route('contrat_details.update-status', $contrat->id)); ?>"
                            class=" mt-3 btn btn-success w-100 <?php if(count($details) == 0): ?> disabled <?php endif; ?> ">Sauvegarder</a>
                    </span>


                </div>
            </div>
        </div> <!-- end card-->


    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('extra-js'); ?>
    <script>
        // SUPPRESSION
        function deleteModal(id) {

            Swal.fire({
                title: "Voulez-vous supprimer l'élément ?",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Oui ",
                cancelButtonText: "Non !",
            }).then(function(result) {
                if (result.value) {
                    window.location.href = "<?php echo e(url('contrats_details/delete')); ?>" + "/" + id;
                    Swal.fire(
                        "Suppression !",
                        "En cours de traitement ...",
                        "success"
                    )
                }
            });
        }





        //EDITION
        function edit(id) {
            var e_id = id;

            // Populate Data in Edit Modal Form
            $.ajax({
                type: "GET",
                url: "<?php echo e(url('getcontratdetails')); ?>" + '/' + e_id,
                success: function(data) {

                    $('#category_test_id2').val(data.category_test_id).change();
                    $('#pourcentage2').val(data.pourcentage);
                    $('#contrat_id2').val(data.contrat_id);
                    $('#contrat_details_id2').val(data.id);



                    console.log(data);
                    $('#editModal').modal('show');
                },
                error: function(data) {
                    console.log('Error:', data);
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kawa/gestion.caap.bj/resources/views/contrats_details/index.blade.php ENDPATH**/ ?>