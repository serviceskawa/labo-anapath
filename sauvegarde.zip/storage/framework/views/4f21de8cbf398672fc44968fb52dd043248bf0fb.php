<?php $__env->startSection('title', 'Templates comptes rendus'); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .ck-editor__editable[role="textbox"] {
            /* editing area */
            min-height: 200px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right mr-3">
                    <a type="button" class="btn btn-primary" href="<?php echo e(route('template.report-index')); ?> ">Tous les templates
                    </a>
                </div>
                <h4 class="page-title">Creer un nouveau template de compte rendu</h4>
            </div>


        </div>
    </div>
    <div class="">

        <?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card my-3">
            <div class="card-header">

                <div class="card-body">

                    <form action="<?php echo e(route('template.report-store')); ?>" method="post" autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <div class="row mb-3">
                            <div class="col-md-12 mb-3">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1" class="form-label">Nom</label>
                                    <input type="hidden" name="id" value="<?php echo e($template ? $template->id : ''); ?>">
                                    <input type="text" class="form-control" name="titre"
                                        value="<?php echo e($template ? $template->title : ''); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-12 mb-3">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1" class="form-label">Contenu</label>
                                    <textarea name="content" id="editor" cols="30" rows="10"><?php echo e($template ? $template->content : ''); ?></textarea>
                                </div>
                            </div>
                        </div>

                </div>

                <div class="modal-footer">
                    <button type="reset" class="btn btn-light" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit"
                        class="btn <?php echo e($template ? 'bg-warning text-white' : 'bg-primary'); ?>"><?php echo e($template ? 'Mettre à jour' : 'Créer'); ?></button>
                </div>


                </form>
            </div>


        </div>

    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('extra-js'); ?>
    <script src="https://cdn.ckeditor.com/ckeditor5/35.1.0/classic/ckeditor.js"></script>
    <script>
        ClassicEditor
            .create(document.querySelector('#editor'))
            .catch(error => {
                console.error(error);
            });
    </script>
    <script>
        ClassicEditor
            .create(document.querySelector('#editor2'))
            .catch(error => {
                console.error(error);
            });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kawa/gestion.caap.bj/resources/views/templates/reports/create.blade.php ENDPATH**/ ?>